/**
 * Citycape Store — ONE app, ONE deploy.
 * -------------------------------------
 * This single server does two jobs at once:
 *   1. Serves the website itself (everything in /public)
 *   2. Sends/verifies real WhatsApp OTP codes via Twilio
 *
 * Why it still needs you to add credentials:
 * Sending a WhatsApp message requires a real Twilio (or Meta) account tied
 * to a real phone number and billing. That step belongs to whoever owns
 * the business — no third party, including an AI, can create or hold that
 * account on your behalf. Everything else here is fully built and ready.
 *
 * DEPLOY THIS AS ONE APP (Render.com, free tier):
 * 1. Push this whole folder to a new GitHub repo.
 * 2. On render.com → New → Web Service → connect that repo.
 * 3. Build command: npm install   |   Start command: node server.js
 * 4. Add environment variables (Render dashboard → Environment):
 *      TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_WHATSAPP_FROM
 * 5. Deploy. Render gives you ONE url, e.g. https://citycape.onrender.com
 *    — that same url serves the shop AND sends the WhatsApp codes.
 * Full walkthrough in SETUP.md.
 */

const express = require('express');
const cors = require('cors');
const path = require('path');
const twilio = require('twilio');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'))); // serves index.html etc.

const {
  TWILIO_ACCOUNT_SID,
  TWILIO_AUTH_TOKEN,
  TWILIO_WHATSAPP_FROM, // e.g. 'whatsapp:+14155238886' (Twilio sandbox number)
  PORT = 3000,
} = process.env;

const twilioReady = TWILIO_ACCOUNT_SID && TWILIO_AUTH_TOKEN && TWILIO_WHATSAPP_FROM;
if (!twilioReady) {
  console.warn(
    '⚠️  Twilio credentials missing. The site will still load, but ' +
    '/api/send-otp will return an error until you set env vars — see SETUP.md.'
  );
}
const client = twilioReady ? twilio(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN) : null;

// In-memory OTP store (fine for one instance / demo traffic). For real scale,
// swap for Redis so codes survive restarts and work across multiple servers.
const otpStore = new Map(); // phone -> { code, expiresAt, attempts }
const generateCode = () => String(Math.floor(100000 + Math.random() * 900000));

app.post('/api/send-otp', async (req, res) => {
  const { phone } = req.body; // E.164 digits only, e.g. "254712345678"
  if (!phone || !/^254(7|1)\d{8}$/.test(phone)) {
    return res.status(400).json({ error: 'Enter a valid Kenyan number, e.g. 254712345678.' });
  }
  if (!client) {
    return res.status(500).json({ error: 'WhatsApp not configured yet. Add Twilio env vars on your host (see SETUP.md).' });
  }

  const code = generateCode();
  otpStore.set(phone, { code, expiresAt: Date.now() + 10 * 60 * 1000, attempts: 0 });

  try {
    await client.messages.create({
      from: TWILIO_WHATSAPP_FROM,
      to: `whatsapp:+${phone}`,
      body: `Your Citycape Store verification code is ${code}. Don't share this with anyone. It expires in 10 minutes.`,
    });
    res.json({ ok: true, message: 'Code sent via WhatsApp.' });
  } catch (err) {
    console.error('Twilio send error:', err.message);
    res.status(500).json({ error: 'Could not send WhatsApp message. Check your Twilio sandbox/number setup.' });
  }
});

app.post('/api/verify-otp', (req, res) => {
  const { phone, code } = req.body;
  const record = otpStore.get(phone);

  if (!record) return res.status(400).json({ error: 'No code was sent to this number. Request a new one.' });
  if (Date.now() > record.expiresAt) {
    otpStore.delete(phone);
    return res.status(400).json({ error: 'Code expired. Request a new one.' });
  }
  record.attempts += 1;
  if (record.attempts > 5) {
    otpStore.delete(phone);
    return res.status(429).json({ error: 'Too many attempts. Request a new code.' });
  }
  if (record.code !== code) {
    return res.status(400).json({ error: 'Incorrect code.' });
  }

  otpStore.delete(phone);
  res.json({ ok: true, verified: true });
});

app.get('/api/health', (req, res) => res.json({ ok: true, whatsappConfigured: twilioReady }));

app.listen(PORT, () => console.log(`Citycape Store running on port ${PORT}`));
