# Citycape Store — one app, one deploy, real WhatsApp codes

Everything — the shop and the WhatsApp sender — is now ONE project. You
deploy it once, to one place, and get one live URL.

The only step nobody else can do for you: creating a Twilio account tied to
your own phone number and billing. That's a Meta/Twilio account-ownership
rule, the same for every business, not something specific to this build.

## Step 1 — Get Twilio WhatsApp working (10 min, free)
1. Sign up: https://www.twilio.com/try-twilio
2. In the Console: **Messaging → Try it out → Send a WhatsApp message**
   → this turns on the free **Sandbox** instantly.
3. On your own phone, open WhatsApp, message the sandbox number shown,
   and send the join code it gives you (e.g. `join brave-tiger`). Anyone
   who needs to *receive* test codes must do this once — sandbox-only rule.
4. Copy your **Account SID**, **Auth Token**, and the sandbox **From** number
   from the Console — you'll need all three.

(When you're ready for real customers with no sandbox step, apply for a
WhatsApp Business sender under Messaging → Senders — Meta reviews it,
usually 1–3 days, then the sandbox restriction goes away.)

## Step 2 — Put this project on GitHub
1. Create a new repo (e.g. `citycape-store`) on https://github.com
2. Upload everything in this `citycape-app` folder to it
   (`server.js`, `package.json`, `.gitignore`, the `public/` folder).
   Do NOT upload a real `.env` file — secrets go in Step 3 instead.

## Step 3 — Deploy on Render (free tier, one platform)
1. Go to https://render.com → sign up → **New +** → **Web Service**
2. Connect the GitHub repo you just created
3. Settings:
   - **Build command:** `npm install`
   - **Start command:** `node server.js`
4. Under **Environment**, add these three variables with your real Twilio
   values from Step 1:
   - `TWILIO_ACCOUNT_SID`
   - `TWILIO_AUTH_TOKEN`
   - `TWILIO_WHATSAPP_FROM`  (format: `whatsapp:+14155238886`)
5. Click **Deploy**. Render builds it and gives you one URL, e.g.
   `https://citycape-store.onrender.com`

That URL is your whole site — shop, cart, sign-up — and sign-up now sends
a real WhatsApp message through your Twilio number. Nothing else to wire up.

## About a free .com / .co.ke
Render's `.onrender.com` address is free and works immediately. A real
custom domain like `citycapestore.com` or `.co.ke` always costs money
yearly (roughly $10–15, or KSh 1,500–2,500 via a registrar like
Truehost/Safaricom Domains) — there's no legitimate permanently-free option
for an owned domain name. Once you buy one, you can point it at your Render
URL for free under Render's custom domain settings.

## Quick local test before deploying (optional)
```bash
npm install
cp .env.example .env   # fill in real Twilio values
node server.js
# open http://localhost:3000
```
